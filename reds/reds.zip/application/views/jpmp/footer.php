<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->

</div>
<!-- jQuery 2.1.4 -->
<script src="<?php echo base_url(); ?>assets/dist/js/app.min.js"></script>

</body>
</html>
